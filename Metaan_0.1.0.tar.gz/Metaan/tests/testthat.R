library(testthat)
library(Metaan)

test_check("Metaan")
